#include "iList.h"

void makeEmpty(iLIST *x) {// リストを初期化する
  x->L = x->R = 0;
}

int isEmpty(iLIST *x) {// リストが空であれば1を，そうでなければ0を返す
  return (x->L == x->R);
}

int size(iLIST *x) {// リストの要素数を返す
  return x->R - x->L;
}

int isFull(iLIST *x) {// リストが一杯であれば1を，そうでなければ0を返す
  return (size(x)==MAXLENGTH);  
}

static int pos(int i) {
  while (i < 0) i += MAXLENGTH;
  return i%MAXLENGTH;
}

void pushFront(iLIST *x, int e) {// リストの先頭に要素eを追加する
  int p = pos(--x->L);
  x->elem[p] = e;
}

void pushBack(iLIST *x, int e) {// リストの末尾に要素eを追加する
  int p = pos(x->R++);
  x->elem[p] = e;
}

int popFront(iLIST *x) {// リストの先頭から要素を取り出す
  int p = pos(x->L++);
  return x->elem[p];
}

int popBack(iLIST *x) {// リストの末尾から要素を取り出す
  int p = pos(--x->R);
  return x->elem[p];
}

int retrieve(iLIST *x, int i) {// リストのi番目の要素を返す
  int p = pos(x->L+i);
  return x->elem[p];
}

void swap(iLIST *x, int i, int j) {// リストのi番目とj番目の要素を入れ替える
  int p = pos(x->L+i);
  int q = pos(x->L+j);
  int temp = x->elem[p];
  x->elem[p] = x->elem[q];
  x->elem[q] = temp;
}

void printList(iLIST *x) {// リストの内容をプリントする
  printf("[");
  for (int i = 0; i < size(x); i++){
    if (i > 0) printf(", ");
    int e = retrieve(x, i);
    printf("%d", e);
  }
  printf("]");
}
