#include <stdio.h>

#define MAXLENGTH   (100)
typedef struct {
  int    L; 
  int    R; 
  int    elem[MAXLENGTH];//要素を格納する配列
} iLIST;

void makeEmpty(iLIST *x);         // リストを初期化する
int isEmpty(iLIST *x);            // リストが空であれば1を，そうでなければ0を返す
int size(iLIST *x);               // リストの要素数を返す
int isFull(iLIST *x);             // リストが一杯であれば1を，そうでなければ0を返す
void pushFront(iLIST *x, int e);  // リストの先頭に要素eを追加する
void pushBack(iLIST *x, int e);   // リストの末尾に要素eを追加する
int popFront(iLIST *x);           // リストの先頭から要素を取り出す
int popBack(iLIST *x);            // リストの末尾から要素を取り出す
int retrieve(iLIST *x, int i);    // リストのi番目の要素を返す
void swap(iLIST *x, int i, int j);// リストのi番目とj番目の要素を入れ替える
void printList(iLIST *x);         // リストの内容をプリントする
