#include <stdio.h>
#include <stdlib.h>
#include "iList.h"
#include "bList.h"

#define NUMBER_OF_BLOCKS     9
#define NUMBER_OF_CHOICES    9
#define NUMBER_OF_DIRECTIONS 4

//赤 -> R, 緑 -> G, 青 -> B, 黄 -> Y, 橙 -> W, 白 -> W
char *BlockShape[NUMBER_OF_BLOCKS][NUMBER_OF_DIRECTIONS] = {
	{"RBGO", "BGOR", "GORB", "ORBG"},
	{"RYGW", "YGWR", "GWRY", "WRYG"},
	{"RYOG", "YOGR", "OGRY", "GRYO"},
	{"ROYW", "OYWR", "YWRO", "WROY"},
	{"RWBG", "WBGR", "BGRW", "GRWB"},
	{"RWBO", "WBOR", "BORW", "ORWB"},
	{"BYOW", "YOWB", "OWBY", "WBYO"},
	{"BGOY", "GOYB", "OYBG", "YBGO"},
	{"BGWY", "GWYB", "WYBG", "YBGW"}
};

int Number_of_Solutions;

void printBoard(char board[6][6]) {
  for (int i = 0; i < 6; i++) {
    if (i%2==0) printf("+--+--+--+\n");
    for (int j = 0; j < 6; j++) {
      if (j%2==0) printf("|");
      printf("%c", board[i][j]);
    }
    printf("|\n");
  } 
  printf("+--+--+--+\n");
}

void printSolution(bLIST *x) { 
  char board[6][6];

  for (int i = 0; i < B_size(x); i++) {
    int row = i/3;
    int col = i%3;
    bSHAPE p = B_retrieve(x, i);
    char *block = BlockShape[p.BlockID][p.Direction];
    board[2*row  ][2*col  ] = block[0];
    board[2*row  ][2*col+1] = block[1];
    board[2*row+1][2*col+1] = block[2];
    board[2*row+1][2*col  ] = block[3];
  }
  printBoard(board);
}

int consistent_H(char *block, char *newblock) {
    for (int i = 0; i < 2; i++) {
      for(int j = 0;j < 2; j++) {
        if (block[i] == newblock[j]) {
            return 0; // 水平方向で一致しているので配置不可
        }
      }
    }
     for (int i = 0; i < 2; i++) {
      for(int j = 0;j < 2; j++) {
        if (block[i+2] == newblock[j+2]) {
            return 0; // 水平方向で一致しているので配置不可
        }
      }
    }
    return 1; // 水平方向で制約を満たしている
}

int consistent_V(char *block, char *newblock) {
    if (block[0] == newblock[3]) return 0;
    if (block[0] == newblock[0]) return 0;
    if (block[3] == newblock[0]) return 0;
    if (block[3] == newblock[0]) return 0;
    for (int i = 0; i < 2; i++) {
      for(int j = 0;j < 2; j++) {
        if (block[i+1] == newblock[j+1]) {
            return 0; // 垂直方向で一致しているので配置不可
        }
      }
    }
    return 1; // 垂直方向で制約を満たしている
}


int appendable(bLIST *x, bSHAPE e) {
  char *newblock = BlockShape[e.BlockID][e.Direction];
  int m   = B_size(x);
  int row = m/3;
  int col = m%3;
  
  for (int i = 3*row; i < m; i++) {// 横方向（同じ行のブロックとの比較）
    bSHAPE p    = B_retrieve(x, i);
    char *block = BlockShape[p.BlockID][p.Direction];
    if (consistent_H(block, newblock) == 0) return 0;
  }
  for (int i = col; i < m; i += 3) {// 縦方向（同じ列のブロックとの比較）  
    bSHAPE p    = B_retrieve(x, i);
    char *block = BlockShape[p.BlockID][p.Direction];
    if (consistent_V(block, newblock)== 0) return 0;
  }
  return 1;
}

void perm(bLIST x, iLIST rest, int r) {//restからr個選んでxの末尾に付加
  if (r == 0) {
    printf("＃%d\n", ++Number_of_Solutions);
    printSolution(&x);
  } else {
    for (int i = 0; i < size(&rest); i++) {
      swap(&rest, 0, i);
      int blockID = popFront(&rest);
      for (int d = 0; d < NUMBER_OF_DIRECTIONS; d++) {
	bSHAPE e = {blockID, d};
	if (appendable(&x, e)) {
	  B_pushBack(&x, e);
	  perm(x, rest, r-1); // 再帰呼び出し
	  B_popBack(&x);
	}
      }
      pushFront(&rest, blockID);
    }
  }
}

int main(void) {
  Number_of_Solutions = 0;
  int n = NUMBER_OF_BLOCKS;
  int r = NUMBER_OF_CHOICES;
  bLIST x; 
  iLIST rest; 
  B_makeEmpty(&x);
  makeEmpty(&rest);
  for (int e = 0; e < n; e++) pushBack(&rest, e);
  perm(x, rest, r); 
  return 0;
} 
