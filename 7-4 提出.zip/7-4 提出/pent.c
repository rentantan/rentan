#include <stdio.h>
#include <stdlib.h>
#include <time.h> // 時間計測用
#include "iList.h"
#include "bList.h"
#include "block.h"
#include "board.h"

int Number_of_Solutions;

void printSolution(bLIST *x) {
    int board[MAXROW][COL];
    initializeBoard(board);
    for (int j = 0; j < B_size(x); j++) {
        POSITION focus = nextFocus(board);
        bSHAPE b = B_retrieve(x, j);
        placeOneBlock(board, focus, b);
    }
    printBoard(board);
}

int appendable(bLIST *x, bSHAPE e) {
    int board[MAXROW][COL];
    initializeBoard(board); // ボードの初期化

    // 現在配置されているブロックをボードに配置
    for (int j = 0; j < B_size(x); j++) {
        bSHAPE b = B_retrieve(x, j);
        POSITION focus = nextFocus(board); // 次の配置場所を取得
        placeOneBlock(board, focus, b); // ボードにブロックを配置
    }

    // 現在のブロック（e）を追加する場所が重複しないか確認
    POSITION focus = nextFocus(board);
    return isPlaceable(board, focus, e); // ボードにブロックを置けるか確認
}

void perm(bLIST x, iLIST rest, int r) { // restからr個選んでxの末尾に付加
    if (r == 0) {
        printf("#%d\n", ++Number_of_Solutions);
        printSolution(&x);
    } else {
        for (int i = 0; i < size(&rest); i++) {
            swap(&rest, 0, i);
            int blockID = popFront(&rest);
            for (int d = 0; d < Block[blockID].Number_of_Directions; d++) {
                bSHAPE e = {blockID, d};
                // 枝刈り: 追加できない場合は再帰を行わない
                if (appendable(&x, e)) {
                    B_pushBack(&x, e);
                    perm(x, rest, r-1); // 再帰呼び出し
                    B_popBack(&x);
                }
            }
            pushFront(&rest, blockID);
        }
    }
}

int main() {
   
    // 実行時間計測の開始
    clock_t start_time = clock();

    Number_of_Solutions = 0;
    int n = NUMBER_OF_BLOCKS;
    int m = 12;
    Height = 10;
    bLIST x; 
    iLIST rest; 
    B_makeEmpty(&x);
    makeEmpty(&rest);
    for (int e = 0; e < n; e++) pushBack(&rest, e);

    // perm 関数の呼び出し
    perm(x, rest, m); 

    // 実行時間計測の終了
    clock_t end_time = clock();
    double time_taken = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("実行時間: %f 秒\n", time_taken);

    return 0;
}
