#ifndef BOARD_H
#define BOARD_H

#include <stdio.h>
#include <stdlib.h>
#include "bList.h"
#include "block.h"

#define MAXROW  12 //縦
#define COL     6 //横

extern int Height;

void initializeBoard(int board[MAXROW][COL]);
void printBoard(int board[MAXROW][COL]);
POSITION nextFocus(int board[MAXROW][COL]);
int isPlaceable(int board[MAXROW][COL], POSITION focus, bSHAPE b);
void placeOneBlock(int board[MAXROW][COL], POSITION focus, bSHAPE b);

#endif
