#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

TREE makeNode(char value, TREE L, TREE R) {
  NODE *nw = (NODE*)malloc(sizeof(NODE));
  if (nw == NULL) return NULL;
  nw->Value      = value;
  nw->L          = L;
  nw->R          = R;
  return nw;
}

void PostOrder(FILE *out, TREE tree) {
  if (tree == NULL) {
    fprintf(stderr, "fatal error\n"); return;
  }
  TREE L = tree->L; // treeの根の左の子
  TREE R = tree->R; // treeの根の右の子
  char  v = tree->Value;

  if (L != NULL && R != NULL) { // 2項演算子を保持
    PostOrder(out, L);
    PostOrder(out, R);
    fprintf(out, "%c, ", (char)v);
  } else if (L != NULL) { // 単項演算子を保持
    PostOrder(out, L);
    fprintf(out, "%c, ", (char)v);
  } else { // 整数値を保持
    fprintf(out, "%c, ", (char)v);
  }
}
