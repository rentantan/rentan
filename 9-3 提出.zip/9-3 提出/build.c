#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "tree.h"

#define BUFFERSIZE 1024
char Buffer[BUFFERSIZE];
int Index;
int ParseError;


// エラーメッセージを出力
void parseError(FILE *out, const char msg[]) {
    ParseError = 1;
    fprintf(out, "%s\n", msg);
    for (int i = 0; i < Index; i++) fprintf(out, " ");
    fprintf(out, "^\n");
}

// 空白文字を削除する関数
void removeWhite(void) {
    int j = 0, c;
    for (int i = 0; (c = Buffer[i]) != '\0'; i++) {
        if (c == ' ' || c == '\t' || c == '\n') continue;
        Buffer[j++] = c;
    }
    Buffer[j] = '\0';
}

// `a`, `b`, `c`, `d` をオペランドとして取得
TREE getOperand(void) {
    char c = Buffer[Index];
    if (c == 'a' || c == 'b' || c == 'c' || c == 'd') {
        TREE tree = makeNode(c, NULL, NULL);
        Index++;
        return tree;
    } else {
        parseError(stderr, "無効な文字です。a, b, c, d のいずれかが期待されます。");
        return NULL;
    }
}

// `E -> P | {P}` を解析
TREE getExpr(void);

// `T -> C | (E) | {E} | [E]` を解析
TREE getT(void) {
    TREE tree;
    char c = Buffer[Index];
    if (c == '(') {
        Index++;
        tree = getExpr();
        if (ParseError) return NULL;
        if (Buffer[Index] == ')') {
            Index++;
        } else {
            parseError(stderr, "閉じ括弧')'がありません。");
            return NULL;
        }
    } else if (c == '{') {
        Index++;
        tree = getExpr();
        if (ParseError) return NULL;
        if (Buffer[Index] == '}') {
            Index++;
            tree = makeNode('*', tree, NULL);  // {E} -> E*
        } else {
            parseError(stderr, "閉じ中括弧'}'がありません。");
            return NULL;
        }
    } else if (c == '[') {
        Index++;
        tree = getExpr();
        if (ParseError) return NULL;
        if (Buffer[Index] == ']') {
            Index++;
            tree = makeNode('?', tree, NULL);  // [E] -> E?
        } else {
            parseError(stderr, "閉じ角括弧']'がありません。");
            return NULL;
        }
    } else {
        tree = getOperand();
        if (ParseError) return NULL;
    }
    return tree;
}

// `P -> T {T}` を解析
TREE getP(void) {
    TREE tree = getT();
    if (ParseError) return NULL;
    while (Buffer[Index] == '{' || Buffer[Index] == '(' || Buffer[Index] == '[' || isalpha(Buffer[Index])) {
        TREE right = getT();
        if (ParseError) return NULL;
        tree = makeNode('.', tree, right);  // {T} -> T{T}
    }
    return tree;
}

// `E -> P | {P}` を解析
TREE getExpr(void) {
    TREE tree = getP();
    if (ParseError) return NULL;
    while (Buffer[Index] == '|') {
        Index++;
        TREE right = getP();
        if (ParseError) return NULL;
        tree = makeNode('+', tree, right);  // P|P
    }
    return tree;
}

// 正規表現の全体解析
TREE getRegex(void) {
    TREE tree = getExpr();
    if (ParseError) return NULL;
    if (Buffer[Index] != '\0') {
        parseError(stderr, "余分な表現があります。");
        return NULL;
    }
    return tree;
}

// 入力を読み取る関数
int mygets(char *s, int n) {
    fgets(s, n, stdin);
    int lg = strlen(s);
    if (lg > 0 && s[lg-1] == '\n') s[--lg] = '\0';
    return lg;
}

int main(void) {
    while (1) {
        ParseError = 0;
        fprintf(stderr, "\n正規表現:=");
        if (mygets(Buffer, BUFFERSIZE) <= 0) break;
        removeWhite();
        Index = 0;
        TREE tree = getRegex();
        if (ParseError) {
            fprintf(stderr, "正しくない正規表現です。\n");
        } else {
            fprintf(stderr, "正規表現が正しいです。Postorder順で出力します:\n");
            PostOrder(stderr, tree);
            fprintf(stderr, "\n");
        }
    }
    return 0;
}
