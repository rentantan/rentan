#ifndef TREE_H
#define TREE_H

#include <stdio.h>

typedef struct Node {
  char Value;
  struct Node *L;
  struct Node *R;
} NODE, *TREE;

TREE makeNode(char value, TREE L, TREE R);
void PostOrder(FILE *out, TREE tree);

#endif
