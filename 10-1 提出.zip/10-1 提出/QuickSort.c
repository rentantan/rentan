#include  <stdio.h>
#include  <stdlib.h>
typedef int DATA_t;

static void swap(DATA_t *x, DATA_t *y) {
  DATA_t tmp = *x;
  *x = *y;
  *y = tmp;
}

static int partition(DATA_t data[], int n)  {
  DATA_t pivot = data[0];
  int i = 0, j = n - 1;
  while (1) {
    while (data[i] < pivot) i++;
    while (data[j] > pivot) j--;
    if (i > j) return i;
    swap(&data[i], &data[j]);
    i++; j--;
  }
}

void QuickSort(DATA_t data[], int n) {
  if (n <= 1) return;
  int m = partition(data, n);
  QuickSort(&data[0], m    );
  QuickSort(&data[m], n - m);
}

