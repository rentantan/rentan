#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void SelectionSort(int data[], int n);
void MergeSort(int data[], int n);
void QuickSort(int data[], int n);

void generateData(int data[], int n) {
  for (int i = 0; i < n; i++) data[i] = rand();
}

void usage(char com[]) {
  printf("使用法: %s <正整数>\n", com);
}

int main(int argc, char *argv[]) {
  if (argc != 2) {
    usage(argv[0]);
    return 1;
  }
  int n = atoi(argv[1]);
  if (n <= 0) {
    usage(argv[0]);
    return 1;
  }
  int *data = (int*)malloc(n*sizeof(int));
  if (data == NULL) {
    printf("メモリが確保できません．\n");
    return 2;
  }
  srand((unsigned int)time(NULL));

  // Selection Sort
  generateData(data, n);
  clock_t start = clock();
  SelectionSort(data, n);
  clock_t end = clock();
  double selectionSortTime = (double)(end - start) / CLOCKS_PER_SEC;
  printf("選択ソートの実行時間: %f秒\n", selectionSortTime);

  // Merge Sort
  generateData(data, n);
  start = clock();
  MergeSort(data, n);
  end = clock();
  double mergeSortTime = (double)(end - start) / CLOCKS_PER_SEC;
  printf("マージソートの実行時間: %f秒\n", mergeSortTime);

  // Quick Sort
  generateData(data, n);
  start = clock();
  QuickSort(data, n);
  end = clock();
  double quickSortTime = (double)(end - start) / CLOCKS_PER_SEC;
  printf("クイックソートの実行時間: %f秒\n", quickSortTime);

  free(data);
  return 0;
}

