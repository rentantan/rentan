#include  <stdio.h>

typedef int DATA_t;

static int FindMaximum(DATA_t data[], int n) {
  int max = 0;
  for (int i = 1; i < n; i++) {
    if (data[max] < data[i]) max = i;
  }
  return max;
}

static void swap(DATA_t *x, DATA_t *y) {
  DATA_t tmp = *x;
  *x = *y;
  *y = tmp;
}

void SelectionSort(DATA_t data[], int n) {
  if (n == 1) return;
  int max = FindMaximum(data, n);
  swap(&data[max], &data[n-1]); 
  SelectionSort(data, n-1);
}
