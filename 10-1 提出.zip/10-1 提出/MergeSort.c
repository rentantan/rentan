#include  <stdio.h>
#include  <stdlib.h>
typedef int DATA_t;

static void Merge(DATA_t A[], int lenA, DATA_t B[], int lenB, DATA_t work[]) {
  int i = 0, j = 0, k = 0;
  while (i < lenA && j < lenB) {
    if (A[i] < B[j]) work[k++] = A[i++];
    else             work[k++] = B[j++];
  }
  while (i < lenA) work[k++] = A[i++];
  while (j < lenB) work[k++] = B[j++];
}

static void MergeSortSub(DATA_t data[], int n, DATA_t work[]) {
  if (n == 1) return;
  int m = n/2;
  MergeSortSub(&data[0], m,     work);
  MergeSortSub(&data[m], n - m, work);
  Merge(&data[0], m, &data[m], n - m, work);
  for (int k = 0; k < n; k++) data[k] = work[k];
}

void MergeSort(DATA_t data[], int n) {
  DATA_t *work = (DATA_t*)malloc(n*sizeof(DATA_t));
  if (work == NULL) return;
  MergeSortSub(data, n, work);
  free(work);
}
