#ifndef BLOCK_H
#define BLOCK_H

#include <stdio.h>

typedef struct {
  int row;
  int col;
} POSITION;

typedef struct {
  char      Name;
  int       Number_of_Directions; // 最大8個
  POSITION  Position[8][5];
} BLOCK;

#define NUMBER_OF_BLOCKS     12

//ブロック名（英文字）と回転・反転により得られる形状のリスト
extern BLOCK Block[NUMBER_OF_BLOCKS];

#endif
