#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "iList.h"
#include "bList.h"
#include "block.h"
#include "board.h"

int Number_of_Solutions;
#define MAX_HASH_SIZE 10000

// ハッシュテーブル
unsigned long hashTable[MAX_HASH_SIZE];

// ハッシュ関数
unsigned long hash(int board[MAXROW][COL]) {
    unsigned long hashValue = 0;
    for (int i = 0; i < MAXROW; i++) {
        for (int j = 0; j < COL; j++) {
            hashValue = hashValue * 31 + board[i][j];
        }
    }
    return hashValue % MAX_HASH_SIZE;
}

// ハッシュテーブルに追加する関数
void addToHashTable(int board[MAXROW][COL]) {
    unsigned long hashValue = hash(board);
    hashTable[hashValue] = 1; // ハッシュテーブルにこの配置があることを示す
}

// ハッシュテーブルに配置があるか確認する関数
int isInHashTable(int board[MAXROW][COL]) {
    unsigned long hashValue = hash(board);
    return hashTable[hashValue] == 1; // 配置がハッシュテーブルにあれば1、なければ0を返す
}

// 90度回転
void rotate90(int board[MAXROW][COL]) {
    int temp[MAXROW][COL];
    for (int i = 0; i < MAXROW; i++) {
        for (int j = 0; j < COL; j++) {
            temp[j][MAXROW - 1 - i] = board[i][j];
        }
    }
    for (int i = 0; i < MAXROW; i++) {
        for (int j = 0; j < COL; j++) {
            board[i][j] = temp[i][j];
        }
    }
}

// 水平反転
void flipHorizontal(int board[MAXROW][COL]) {
    for (int i = 0; i < MAXROW; i++) {
        for (int j = 0; j < COL / 2; j++) {
            int temp = board[i][j];
            board[i][j] = board[i][COL - j - 1];
            board[i][COL - j - 1] = temp;
        }
    }
}

// 垂直反転
void flipVertical(int board[MAXROW][COL]) {
    for (int i = 0; i < MAXROW / 2; i++) {
        for (int j = 0; j < COL; j++) {
            int temp = board[i][j];
            board[i][j] = board[MAXROW - i - 1][j];
            board[MAXROW - i - 1][j] = temp;
        }
    }
}

// 配置の正規化：回転・反転を行い、最も基本的な形を取得
void normalizeBoard(int board[MAXROW][COL]) {
    int temp[MAXROW][COL];
    memcpy(temp, board, sizeof(int) * MAXROW * COL);  // 初期状態を保存

    int minHash = hash(board);
    
    // すべての回転・反転バリエーションを試す
    for (int i = 0; i < 4; i++) {
        rotate90(temp);
        for (int j = 0; j < 2; j++) {
            if (j == 1) flipHorizontal(temp);
            for (int k = 0; k < 2; k++) {
                if (k == 1) flipVertical(temp);
                
                // 最小のハッシュを選定
                unsigned long tempHash = hash(temp);
                if (tempHash < minHash) {
                    minHash = tempHash;
                }
            }
        }
    }

    // 最小のハッシュ値に対応する配置に変更
    if (minHash == hash(board)) {
        return;
    }

    // 正規化された配置をハッシュテーブルに追加
    if (!isInHashTable(board)) {
        addToHashTable(board);
    }
}

// 配置済みブロックのバリエーションが同じかチェック
int isUniqueSolution(int board[MAXROW][COL]) {
    int temp[MAXROW][COL];
    memcpy(temp, board, sizeof(int) * MAXROW * COL);
    normalizeBoard(temp);  // 配置を正規化

    // ハッシュテーブルにすでに配置があるか確認
    return !isInHashTable(temp);
}

void printSolution(bLIST *x) {
    int board[MAXROW][COL];
    initializeBoard(board);
    for (int j = 0; j < B_size(x); j++) {
        POSITION focus = nextFocus(board);
        bSHAPE b = B_retrieve(x, j);
        placeOneBlock(board, focus, b);
    }
    printBoard(board);
}

int appendable(bLIST *x, bSHAPE e) {
    int board[MAXROW][COL];
    initializeBoard(board);  // ボードの初期化

    // 現在配置されているブロックをボードに配置
    for (int j = 0; j < B_size(x); j++) {
        bSHAPE b = B_retrieve(x, j);
        POSITION focus = nextFocus(board);  // 次の配置場所を取得
        placeOneBlock(board, focus, b);    // ボードにブロックを配置
    }

    // 現在のブロック（e）を追加する場所が重複しないか確認
    POSITION focus = nextFocus(board);
    return isPlaceable(board, focus, e);  // ボードにブロックを置けるか確認
}

void perm(bLIST x, iLIST rest, int r) {
    if (r == 0) {
        int board[MAXROW][COL];
        initializeBoard(board);
        for (int j = 0; j < B_size(&x); j++) {
            POSITION focus = nextFocus(board);
            bSHAPE b = B_retrieve(&x, j);
            placeOneBlock(board, focus, b);
        }
        
        // ユニークな配置かチェック
        if (isUniqueSolution(board)) {
            printf("#%d\n", ++Number_of_Solutions);
            printSolution(&x);
        }
    } else {
        for (int i = 0; i < size(&rest); i++) {
            swap(&rest, 0, i);
            int blockID = popFront(&rest);
            for (int d = 0; d < Block[blockID].Number_of_Directions; d++) {
                bSHAPE e = {blockID, d};
                if (appendable(&x, e)) {
                    B_pushBack(&x, e);
                    perm(x, rest, r - 1);
                    B_popBack(&x);
                }
            }
            pushFront(&rest, blockID);
        }
    }
}

int main() {
    // 実行時間計測の開始
    clock_t start_time = clock();

    Number_of_Solutions = 0;
    int n = NUMBER_OF_BLOCKS;
    int m = 12;
    Height = 10;
    bLIST x;
    iLIST rest;
    B_makeEmpty(&x);
    makeEmpty(&rest);
    for (int e = 0; e < n; e++) pushBack(&rest, e);

    // ハッシュテーブル初期化
    memset(hashTable, 0, sizeof(hashTable));

    // perm 関数の呼び出し
    perm(x, rest, m);

    // 実行時間計測の終了
    clock_t end_time = clock();
    double time_taken = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("実行時間: %f 秒\n", time_taken);

    return 0;
}
