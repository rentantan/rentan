#include "bList.h"

void B_makeEmpty(bLIST *x) {// リストを初期化する
  x->L = x->R = 0;
}

int B_isEmpty(bLIST *x) {// リストが空であれば1を，そうでなければ0を返す
  return (x->L == x->R);
}

int B_size(bLIST *x) {// リストの要素数を返す
  return x->R - x->L;
}

int B_isFull(bLIST *x) {// リストが一杯であれば1を，そうでなければ0を返す
  return (B_size(x)==MAXLENGTH);  
}

static int pos(int i) {
  while (i < 0) i += MAXLENGTH;
  return i%MAXLENGTH;
}

void B_pushFront(bLIST *x, bSHAPE e) {// リストの先頭に要素eを追加する
  int p = pos(--x->L);
  x->elem[p] = e;
}

void B_pushBack(bLIST *x, bSHAPE e) {// リストの末尾に要素eを追加する
  int p = pos(x->R++);
  x->elem[p] = e;
}

bSHAPE B_popFront(bLIST *x) {// リストの先頭から要素を取り出す
  int p = pos(x->L++);
  return x->elem[p];
}

bSHAPE B_popBack(bLIST *x) {// リストの末尾から要素を取り出す
  int p = pos(--x->R);
  return x->elem[p];
}

bSHAPE B_retrieve(bLIST *x, int i) {// リストのi番目の要素を返す
  int p = pos(x->L+i);
  return x->elem[p];
}

void B_swap(bLIST *x, int i, int j) {// リストのi番目とj番目の要素を入れ替える
  int p = pos(x->L+i);
  int q = pos(x->L+j);
  bSHAPE temp = x->elem[p];
  x->elem[p] = x->elem[q];
  x->elem[q] = temp;
}

void B_printList(bLIST *x) {// リストの内容をプリントする
  printf("[");
  for (int i = 0; i < B_size(x); i++){
    if (i > 0) printf(", ");
    bSHAPE e = B_retrieve(x, i);
    printf("(%d,%d)", e.BlockID, e.Direction);
  }
  printf("]");
}
