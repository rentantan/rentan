#ifndef BLIST_H
#define BLIST_H

#include <stdio.h>

typedef struct {
  int BlockID;   // 0, 1, ..., 9
  int Direction; // 0, 1
} bSHAPE;

#define MAXLENGTH   (100)
typedef struct {
  int    L; 
  int    R; 
  bSHAPE elem[MAXLENGTH];//要素を格納する配列
} bLIST;

void B_makeEmpty(bLIST *x);         // リストを初期化する
int B_isEmpty(bLIST *x);            // リストが空であれば1を，そうでなければ0を返す
int B_size(bLIST *x);               // リストの要素数を返す
int B_isFull(bLIST *x);             // リストが一杯であれば1を，そうでなければ0を返す
void B_pushFront(bLIST *x, bSHAPE e);  // リストの先頭に要素eを追加する
void B_pushBack(bLIST *x, bSHAPE e);   // リストの末尾に要素eを追加する
bSHAPE B_popFront(bLIST *x);           // リストの先頭から要素を取り出す
bSHAPE B_popBack(bLIST *x);            // リストの末尾から要素を取り出す
bSHAPE B_retrieve(bLIST *x, int i);    // リストのi番目の要素を返す
void B_swap(bLIST *x, int i, int j);// リストのi番目とj番目の要素を入れ替える
void B_printList(bLIST *x);         // リストの内容をプリントする

#endif
