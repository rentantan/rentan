#include "board.h"

int Height;

void initializeBoard(int board[MAXROW][COL]) {
  for (int row = 0; row < Height; row++) {
    for (int col = 0; col < COL; col++) {
      board[row][col] = -1;
    }
  }
}

void printBoard(int board[MAXROW][COL]) {
  for (int row = 0; row < Height; row++) {
    for (int col = 0; col < COL; col++) {
      int id = board[row][col];
      char ch = (id>=0)? Block[id].Name: '-';
      printf("%c", ch);
    }
    printf("\n");
  }
  printf("\n");
}

POSITION nextFocus(int board[MAXROW][COL]) {
  //次に埋めるべきboardの位置focusを返す．一杯のときは位置{-1,-1}を返す．
  POSITION focus = {-1,-1};
  for (int row = 0; row < Height; row++) {
    for (int col = 0; col < COL; col++) {
      if (board[row][col] == -1) {
	focus.row = row;
	focus.col = col;
	return focus;
      }
    }
  }
  return focus;
}

int isPlaceable(int board[MAXROW][COL], POSITION focus, bSHAPE b) {
  //ブロック形状bをboardの位置focusに置ければ1を，置けなければ0を返す．
  for (int k = 0; k < 5; k++) {
    int row = focus.row + Block[b.BlockID].Position[b.Direction][k].row;
    int col = focus.col + Block[b.BlockID].Position[b.Direction][k].col;
    if (row < 0 || Height <= row) return 0; // はみ出す
    if (col < 0 || COL    <= col) return 0; // はみ出す
    if (board[row][col] != -1) return 0; // 既にブロックが置かれている
  }
  return 1;
}

void placeOneBlock(int board[MAXROW][COL], POSITION focus, bSHAPE b) {
  //ブロック形状bをboardの位置focusに置く．
  for (int k = 0; k < 5; k++) {
    int row = focus.row + Block[b.BlockID].Position[b.Direction][k].row;
    int col = focus.col + Block[b.BlockID].Position[b.Direction][k].col;
    board[row][col] = b.BlockID;
  }
}
