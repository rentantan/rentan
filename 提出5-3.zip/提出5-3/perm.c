#include <stdio.h>
#include <stdlib.h>
#include "iList.h"

// 条件を満たすかどうかをチェックする関数
int isValid(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (abs(arr[i] - arr[j]) == (j - i)) {
                return 0; // 条件を満たさない
            }
        }
    }
    return 1; // 条件を満たす
}

// 順列を生成する再帰関数
void perm(iLIST x, iLIST rest, int r) {
    if (r == 0) {
        // 順列が完成したので条件を満たしているかチェック
        int arr[size(&x)];
        for (int i = 0; i < size(&x); i++) {
            arr[i] = retrieve(&x,i);
       }
        if (isValid(arr, size(&x))) {
            // 条件を満たしている場合は出力
            printList(&x);
            printf("\n");
        }
    } else {
        for (int i = 0; i < size(&rest); i++) {
            swap(&rest, 0, i);
            int e = popFront(&rest);
            pushBack(&x, e);
            perm(x, rest, r-1); // 再帰呼び出し
            popBack(&x);
            pushFront(&rest, e);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage:\n%s <n>\n", argv[0]);
        return 1;
    }
    int n = atoi(argv[1]);
    iLIST x, rest;
    makeEmpty(&x);
    makeEmpty(&rest);
    for (int e = 0; e < n; e++) pushBack(&rest, e);
    perm(x, rest, n);
    return 0;
}
