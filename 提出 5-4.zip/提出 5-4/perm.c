#include <stdio.h>
#include <stdlib.h>
#include "iList.h"

// 条件を満たすかどうかをチェックする関数
int isValid(iLIST *x) {
    int n = size(x);
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (abs(retrieve(x, i) - retrieve(x, j)) == (j - i)) {
                return 0; // 条件を満たさない
            }
        }
    }
    return 1; // 条件を満たす
}

// 順列を生成する再帰関数（枝刈りあり）
void perm(iLIST x, iLIST rest, int r) {
    if (r == 0) {
        // 順列が完成したので条件を満たしているかチェック
        if (isValid(&x)) {
            // 条件を満たしている場合は出力
            printList(&x);
            printf("\n");
        }
    } else {
        for (int i = 0; i < size(&rest); i++) {
            swap(&rest, 0, i);    // restから取り出す前に位置を交換
            int e = popFront(&rest);  // 先頭の要素を取り出し
            pushBack(&x, e);        // xに追加

            // 現在の順列が条件を満たしているか確認
            if (isValid(&x)) {
                perm(x, rest, r - 1);  // 再帰呼び出し
            }

            // 戻す処理
            popBack(&x);
            pushFront(&rest, e);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage:\n%s <n>\n", argv[0]);
        return 1;
    }
    int n = atoi(argv[1]);
    iLIST x, rest;
    makeEmpty(&x);
    makeEmpty(&rest);
    for (int e = 0; e < n; e++) pushBack(&rest, e);
    perm(x, rest, n);  // 順列生成開始
    return 0;
}
